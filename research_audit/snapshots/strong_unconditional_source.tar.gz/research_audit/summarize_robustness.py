"""Generate manuscript tables and figures from all declared robustness arms."""
import json
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def main():
    root=Path('research_audit/results'); paper=Path('paper'); (paper/'images').mkdir(exist_ok=True)
    arms=['compact','rps','conditional','mild']
    names=['Scalar','Ordinal','Ordinal + blur 1.5','Ordinal + blur 0.75']
    extra_stages={'scalar_cond':'scalar_stage','unconditional':'unconditional_stage',
                  'resnet_baseline':'resnet_stage','resnet_cond':'resnet_stage',
                  'strong_unconditional':'strong_unconditional_stage'}
    extra_names={'scalar_cond':'Scalar + conditional blur 0.75','unconditional':'Scalar + unconditional blur 0.75',
                 'resnet_baseline':'ResNet-18 scalar','resnet_cond':'ResNet-18 + conditional blur 0.75',
                 'strong_unconditional':'Ordinal + unconditional blur 1.5'}
    pending=[]
    for arm,stage in extra_stages.items():
        if all((root/stage/'evaluations'/f'ordinal_{arm}_seed{s}'/'metrics.json').exists() for s in [42,123,456]):
            arms.append(arm); names.append(extra_names[arm])
        else: pending.append(arm)
    result={'warning':'Seed SD describes training variation, not patient-level confidence.', 'pending_arms':pending,'arms':{}}
    for arm in arms:
        stage=extra_stages.get(arm,'screening' if arm=='compact' else 'mild_stage' if arm=='mild' else 'ordinal_stage')
        scores=[]; probes=[]
        for seed in [42,123,456]:
            directory=f'compact448_seed{seed}' if arm=='compact' else f'ordinal_{arm}_seed{seed}'
            scores.append(json.loads((root/stage/'evaluations'/directory/'metrics.json').read_text()))
            probe_stage='ordinal_stage' if arm=='compact' else stage
            probes.append(json.loads((root/probe_stage/'probes'/f'{arm}_seed{seed}'/'metrics.json').read_text())['summary'])
        entry={'test':{k:{'mean':float(np.mean([r[k] for r in scores])),
                         'sample_sd':float(np.std([r[k] for r in scores],ddof=1))}
                       for k in ['PLCC','SROCC','KROCC','Aggregate','mae']},'probe':{}}
        for variant in probes[0]:
            entry['probe'][variant]={}
            for group in probes[0][variant]:
                entry['probe'][variant][group]={key:{'mean':float(np.mean([r[variant][group][key] for r in probes])),
                    'sample_sd':float(np.std([r[variant][group][key] for r in probes],ddof=1))}
                    for key in ['mean_delta','fraction_score_increases']}
                entry['probe'][variant][group]['n']=probes[0][variant][group]['n']
        external=[root/'external_gpu'/f'{arm}_seed{s}'/'metrics.json' for s in [42,123,456]]
        if all(path.exists() for path in external):
            records=[json.loads(path.read_text()) for path in external]
            entry['external']={key:{'mean':float(np.mean(values)),'sample_sd':float(np.std(values,ddof=1))}
                for key,values in {
                    'SROCC':[r['overall']['SROCC'] for r in records],
                    'CHEST_SROCC':[r['by_anatomy']['CHEST']['SROCC'] for r in records],
                    'PELVIS_SROCC':[r['by_anatomy']['PELVIS']['SROCC'] for r in records],
                    'pair_agreement':[r['reconstruction_pair_agreement']['agreement'] for r in records]}.items()}
        result['arms'][arm]=entry
    (root/'robustness_summary.json').write_text(json.dumps(result,indent=2))
    lines=['\\begin{table}[ht]\\centering\\small',
           '\\caption{Released LDCT test results, mean $\\pm$ sample SD over three training seeds on one fixed test collection.}',
           '\\begin{tabular}{lrr}\\toprule Model & Aggregate $\\uparrow$ & MAE $\\downarrow$ \\\\ \\midrule']
    for arm,name in zip(arms,names):
        t=result['arms'][arm]['test']; a,m=t['Aggregate'],t['mae']
        lines.append(f"{name} & ${a['mean']:.4f}\\pm{a['sample_sd']:.4f}$ & ${m['mean']:.4f}\\pm{m['sample_sd']:.4f}$ \\\\")
    lines+=['\\bottomrule\\end{tabular}\\label{tab:ldct}\\end{table}']
    if all('external' in result['arms'][a] for a in arms):
        lines+=['\\begin{table}[ht]\\centering\\small',
                '\\caption{External CBCT-IQ phantom transfer, mean $\\pm$ seed SD. All models use fixed inference on 1,666 expert-annotated slices.}',
                '\\begin{tabular}{lrr}\\toprule Model & Spearman $\\uparrow$ & Pair agreement $\\uparrow$ \\\\ \\midrule']
        for arm,name in zip(arms,names):
            e=result['arms'][arm]['external']; s,a=e['SROCC'],e['pair_agreement']
            lines.append(f"{name} & ${s['mean']:.3f}\\pm{s['sample_sd']:.3f}$ & ${a['mean']:.3f}\\pm{a['sample_sd']:.3f}$ \\\\")
        lines+=['\\bottomrule\\end{tabular}\\label{tab:external}\\end{table}']
    (paper/'results_generated.tex').write_text('\n'.join(lines)+'\n')
    plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    colors=['#345d7e','#8b8b8b','#cc8c38','#208c80']
    figure_arms=['compact','rps','conditional','mild']
    means=[result['arms'][a]['test']['Aggregate']['mean'] for a in figure_arms]
    std=[result['arms'][a]['test']['Aggregate']['sample_sd'] for a in figure_arms]
    labels=['Scalar','Ordinal','Blur 1.5','Blur 0.75']
    for i,(mean,sd,color) in enumerate(zip(means,std,colors)):
        axes[0].errorbar(i,mean,yerr=sd,fmt='o',capsize=4,color=color,markersize=7)
    axes[0].set_xticks(range(4),labels)
    axes[0].set_xlim(-.5,3.5)
    axes[0].set_ylim(2.6,2.8); axes[0].set_ylabel('LDCT test aggregate'); axes[0].set_title('(a) Benchmark score: mean and seed SD')
    variants=['gaussian_0.75','gaussian_1.5','box_5']; x=np.arange(3)
    for index,arm in enumerate(figure_arms):
        values=[result['arms'][arm]['probe'][v]['target_at_least_3']['fraction_score_increases']['mean']*100 for v in variants]
        deviations=[result['arms'][arm]['probe'][v]['target_at_least_3']['fraction_score_increases']['sample_sd']*100 for v in variants]
        axes[1].bar(x+(index-1.5)*.19,values,yerr=deviations,capsize=3,width=.18,label=labels[index],color=colors[index])
        for position,value in zip(x+(index-1.5)*.19,values):
            if value==0: axes[1].text(position,1,'0',ha='center',va='bottom',fontsize=8,color=colors[index])
    axes[1].set_xticks(x,['Gaussian 0.75','Gaussian 1.5','Box filter 5'])
    axes[1].set_ylim(0,105); axes[1].set_ylabel('Altered image receives higher score (%)')
    axes[1].set_title('(b) Synthetic probes on 49 high-rated slices')
    axes[1].legend(fontsize=10.5,ncol=2)
    fig.savefig(paper/'images/robustness_tradeoff.png',dpi=220)
    fig.savefig(paper/'images/robustness_tradeoff.svg')
    plt.close(fig)
    print(json.dumps({a:result['arms'][a]['test']['Aggregate'] for a in arms},indent=2))


if __name__=='__main__': main()
