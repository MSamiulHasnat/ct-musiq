"""CT-MUSIQ research code."""
